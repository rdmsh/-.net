<?php

namespace Common\Auth\Events;

use App\User;

class UserCreated
{
    /**
     * @var User
     */
    public $user;

    /**
     * @param User $user
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }
}